<div id="content">

	<h2>Header: Post Page</h2>
	
	<?php
		echo("<strong>Post</strong>: ".$posts["title"]."<br /><strong>Details</strong>: ".$posts["detail"]."<br /><br /><a href=\"http://localhost/websites/CodeIgniter_2.1.3/index.php\">&lt;&lt; Back to Home Page</a>");
	 ?>

</div>