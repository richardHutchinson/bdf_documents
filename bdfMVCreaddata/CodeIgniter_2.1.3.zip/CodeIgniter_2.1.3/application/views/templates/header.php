<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" href="http://localhost/websites/ssl/day6/css/style.css" type="text/css" />
		<link rel="shortcut icon" href="http://localhost/websites/ssl/day6/images/pt-url-image.png" />
		<title>ProTask Management System</title>
	</head>
	
	<body>
		<div id="master-container">
			<div id="header-repeat"></div>
			<div id="content-container">
				<div id="header">
					<div id="header-logo">
						<a href="#">
							<img src="http://localhost/websites/ssl/day6/images/protask-logo-1.jpg" />
						</a>
					</div>
					<div id="main-nav">
						<ul id="nav-list">
							<li id="home"><a href="#"></a></li>
							<li id="features"><a href="#"></a></li>
							<li id="tools"><a href="#"></a></li>
							<li id="addons"><a href="#"></a></li>
							<li id="about"><a href="#"></a></li>
						</ul>
					</div>
					<!--<div id="sign-in">
						<a href="#">
							<img src="./images/protask-sign-in.jpg" />
						</a>
					</div>-->
					<div id="log-in">
						<form name="log-in" method="get" action="#">
							<label for="email">Email:</label>
							<span class="input-1">
								<input type="text" name="email" />
							</span>
							<label for="password">Password:</label>
							<span class="input-1">
								<input type="password" name="password" />
							</span>
						</form>
					</div>
					<div id="sign-up">
						<a href="#">
							<img src="http://localhost/websites/ssl/day6/images/protask-sign-up.jpg" />
						</a>
					</div>
					<div id="catch"></div>
				</div>