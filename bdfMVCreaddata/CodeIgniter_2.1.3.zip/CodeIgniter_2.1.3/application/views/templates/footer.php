		<div class="push"></div>
			<div class="clear"></div>
		</div>
		<div id="footer-repeat">
			<div id="footer">
				<span id="footer-logo">
					<img src="http://localhost/websites/ssl/day6/images/protask-logo-2.jpg" />
				</span>
				<span class="p1">
					All trademarks referenced herein are the properties of
					<br />
					&copy; 2012 ProTast | All rights reserved
				</span>
			</div>
		</div>
	</body>
</html>