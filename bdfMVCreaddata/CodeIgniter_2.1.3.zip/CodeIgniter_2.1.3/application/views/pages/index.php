<div id="content">

	<h2>Header: Index Page</h2>
	
	<?php foreach($post as $posts){ ?>
	
		<h3>
			<?php
				//echo $posts['title']
				/*echo("Title: ".$posts['title']);*/
			?>
		</h3>
		
		<div id="main">
			<?php /*echo("Details: ".$posts['detail']);*/ ?>
		</div>
		<p>
			<?php
				echo("<strong>Post: </strong>".$posts["title"]);
			?>
			
			<a href="index.php/posts/<?php echo $posts['postId'] ?>">Details &gt;&gt;</a>
		</p>
	
	<?php } ?>

</div>