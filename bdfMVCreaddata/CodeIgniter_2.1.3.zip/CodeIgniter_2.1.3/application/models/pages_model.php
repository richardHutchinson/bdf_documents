<?php
	class Pages_model extends CI_Model {
	
		public function __construct(){
			$this->load->database();
		}
		
		public function get_post($postId = false){
			
			if($postId === false){
				$query = $this->db->get('post');
				return $query->result_array();
			}
			
			$query = $this->db->get_where('post', array('postId' => $postId));
			return $query->row_array();
		}
	}
?>